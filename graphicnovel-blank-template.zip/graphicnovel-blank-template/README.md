# GraphicNovel — blank tutorial template

A blank starting point for GraphicNovel v0.5. No story, characters, locations, dialogue, dates or artwork are supplied. Empty braces are fields to fill, not example content.

## Files

- `graphicnovel-blank.tex`: complete single-file document. Use this for the website compiler and tutorial excerpts.
- `document.tex`: main document for a local, split-file project.
- `bible.tex`: blank reference Bible, loaded before the document begins.
- `script.tex`: blank story, comic page, panel and lettering directives, loaded inside the document.
- `graphicnovel.cls`: unmodified class, v0.5 dated 22 September 2026.

The combined document contains the same Bible and script as the separate files. It uses neither `\input` nor TeX comments, which the website's restricted compiler does not accept. For local LaTeX, keep all four split-project files together and compile `document.tex` with PDFLaTeX.

## Fill, then compile

This is an editing template, not a ready-to-compile example. Blank names, eras, appearance descriptions, shots and layout specifications deliberately fail required-field or consistency checks. Fill required fields and remove unused optional commands or whole entries before compiling.

1. Name an era. Use exactly that name in appearance records and the script's `\era{}`.
2. Name the characters, locations and props that the script actually uses. Supply their appearances for the relevant era. Remove unused entries.
3. Fill the story title and page layout. `\pageLayout{}` takes a comma-separated list of positive integers giving the panel count in each row; those counts must match the panels supplied.
4. Fill each panel's location and visual direction. Character, prop, expression and tell references must match Bible declarations. Delete optional references that are not needed.
5. Add lettering in reading order. Delete unused dialogue, caption, sound-effect and note commands.

## Lettering and dialogue boxes

```tex
\dialogue[position={},note={}]{}{}
```

The two brace arguments are the character name and spoken text. `position` records balloon placement. `note` records lettering or delivery instructions. Duplicate the command for each balloon. The optional `off` flag marks off-panel speech: `\dialogue[off,position={},note={}]{}{}`.

`\caption{}` records caption-box text. `\sfx{}` records sound effects. `\note{}` records panel instructions, including caption-box placement or lettering style.

The class produces a production script containing these instructions. It does not draw finished comic panels, speech balloons or caption boxes. Those can be illustrated separately in the tutorial and Kickstarter material.

## Tutorial sections

Blank lines separate eras, characters, locations, props, continuity, story, page layout, panel direction, continuity references and lettering. Copy a block into a tutorial and fill it there. Add tutorial headings outside the source blocks: the website compiler accepts supported directives, not prose or TeX comments. Keep Bible declarations before `\begin{document}` and script directives inside it.

## Licence and maintainer

Copyright © 2026 Tom Bronte. This template bundle, including its template sources, README and unchanged class, is distributed under the LaTeX Project Public License 1.3c or later: https://www.latex-project.org/lppl/ . The work consists of `graphicnovel-blank.tex`, `document.tex`, `bible.tex`, `script.tex`, `README.md` and `graphicnovel.cls`.

Maintenance status: maintained. Current maintainer: Tom Bronte. Contact: craftsyntax@craftsyntax.uk.

Project source and manuals: https://github.com/craftsyntax-uk/GraphicNovel

Technical verification: the template commands and dialogue options were checked against the supplied v0.5 class and compiler parser. A temporarily filled copy passed parser and reference checks in Draft and Production. No populated example is distributed. PDF rendering was not tested in the authoring environment.
